#JKI Unicode

JKI Unicode is a library for manipulating unicode strings in LabVIEW.

## Installation

You can download and install JKI Unicode with VI Package Manager.

[Get JKI Unicode](http://vipm.jki.net/#!/package/jki_lib_unicode)

## Contributing

1. Fork it!
2. Create your feature branch: `git checkout -b my-new-feature`
3. Commit your changes: `git commit -am 'Add some feature'`
4. Push to the branch: `git push origin my-new-feature`
5. Submit a pull request

To contribute to JKI Unicode, you will need 32-bit LabVIEW 2010 f2 professional development environment. 

## Credits

JKI Unicode is an open source project maintained by [JKI](http://jki.net).

## License

JKI Unicode is distributed under the open source three clause BSD license providing everyone right to use and distribute both souce code 
and compiled versions of JKI Unicode. See LICENSE.md file for details.
